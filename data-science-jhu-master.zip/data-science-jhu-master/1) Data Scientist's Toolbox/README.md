datasciencecoursera
===================

It's a repository about Data Scientist's toolbox course on Coursera from John Hopkins University. 
It's a simple readme file.
