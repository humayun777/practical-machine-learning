pollutantmean <- function(directory, pollutant, id = 1:332)
      