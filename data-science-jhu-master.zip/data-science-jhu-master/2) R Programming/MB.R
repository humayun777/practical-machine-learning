structure(list(d = 21, m = 8, y = 1990), .Names = c("d", "m", 
"y"), row.names = c(NA, -1L), class = "data.frame")
