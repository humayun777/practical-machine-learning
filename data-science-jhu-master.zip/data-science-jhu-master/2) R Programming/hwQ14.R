structure(list(X14 = c(18L, 20L), X191 = c(131L, 223L), X14.3 = c(8, 
11.5), X75 = c(76L, 68L), X9 = c(9L, 9L), X28 = 29:30), .Names = c("X14", 
"X191", "X14.3", "X75", "X9", "X28"), class = "data.frame", row.names = c(NA, 
-2L))
